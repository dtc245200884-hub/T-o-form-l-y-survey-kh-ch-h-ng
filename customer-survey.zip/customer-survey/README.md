# Customer Survey Form

A responsive customer market research survey built with HTML and CSS.

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a web browser.

## Files
- `index.html` — survey form structure and fields
- `style.css` — layout, colors, responsive design

Note: This is a front-end practice form. It does not store or send submitted responses to a server.
